#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <omp.h>

double initial_time;
double clearcache [30000000];

void clearCache(void){
	int i;
	for (i = 0; i < 30000000; ++i)
		clearcache[i] = i;
}

void start(){
	double time = omp_get_wtime();
	initial_time = time;
}

double stop(){
	double time = omp_get_wtime();
	double final = time;
	
	return final - initial_time;
}

double** init_mat(int size){

	int i;
	double** aux __attribute__ ((aligned(32))) = calloc(size, sizeof(double*));
    
	for (i=0; i<size; i++) {
        aux[i] = calloc(size, sizeof(double));
    }

	return aux;
}

void fillMatrices (double** A,double** B,double** C,int size) {

	int i,j;
   
	srand(time(NULL));
	for ( i = 0; i < size; i++) {
		for (j = 0; j < size; j++) {
			A[i][j] = ((double) rand()) / ((double) RAND_MAX);
			B[i][j] = ((double) rand()) / ((double) RAND_MAX);
			C[i][j] = 0.0;				
		}		
	}
}

void printMatrix(double** matrix,int size) {

    int i, j;
    for(i = 0; i < size; i++) {
        for(j = 0; j < size; j++)
            printf("%f ",matrix[i][j]); 
        printf("\n");
    }
    printf("\n-----------------------------------------------------------------------------------------------\n");
}


void multiplicationBlockOMP(double** A,double** B,double** C,int size){

	int i, j, k, ii, jj, kk;
	int block_size = 64;
	
	#pragma omp parallel for schedule(dynamic) private(i,j,k) shared(A,B,C,ii,jj,kk)
	for(ii = 0; ii < size; ii += block_size){
		for(kk = 0; kk < size; kk += block_size){
			for(jj = 0; jj < size; jj += block_size){
				for(i = ii; i < ii + block_size && i < size; i++){
					for(k = kk; k < kk + block_size && k < size; k++){
						for(j = jj; j < jj + block_size && j < size; j++){
							C[i][j] += A[i][k] * B[k][j];
						}
      				}
    			}
  			}
  		}
  	}
}

int main(int argc, char const *argv[]){

	int i,size;

	size = 4096;

	double** A __attribute__ ((aligned(32))) = init_mat(size);
	double** B __attribute__ ((aligned(32))) = init_mat(size);
	double** C __attribute__ ((aligned(32))) = init_mat(size);

	fillMatrices(A,B,C,size);
	//printMatrix(A, size);
	//printMatrix(B, size);
	
	clearCache();
   
	double tempo;
	
	clearCache();

	start();

	multiplicationBlockOMP(A,B,C,size);

	tempo = stop();
	printf("Demorou %f segundos\n",tempo);
	//printMatrix(C, size);
}

